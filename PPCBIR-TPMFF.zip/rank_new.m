function [order,num]=rank_new(array)
num=0;
sum_4=sum(array);
if sum_4>510
    start=sum_4-510;
else
    start=0;
end

for left=start:1:min(510,sum_4)
    right=sum_4-left;
    if left<=255    
        left_num=left+1;
    else
        left_num=511-left;
    end
    if right<=255
        right_num=right+1;
    else
        right_num=511-right;
    end
    
    if left~=array(1)+array(2)
        num=num+left_num*right_num;
    else
        if left>255
            start=left-255;
        else
            start=0;
        end
        for left_L=start:1:min(255,left)
            if left_L==array(1)
                left_L_num=left_L-start;
                if right>255
                    start=right-255;
                else
                    start=0;
                end
                for right_L=start:1:min(255,right)
                    if right_L==array(3)
                        right_L_num=right_L-start+1;
                        break;
                    end
                end
                break;      
            end
        end
        order=num+left_L_num*right_num+right_L_num;
        num=num+left_num*right_num;
    end
end
end
            
