function [DR,DG,DB]=Decryption_CA(ER,EG,EB,ca,K1,K2,key)
ER=double(ER);
EG=double(EG);
EB=double(EB);
[wd,hd]=size(ER);
sub_wd = wd / K2;
sub_hd = hd / K2;
encry_order1=fprng(double(key(33:48)),K1*K1);
encry_order2=fprng(double(key(33:48)),K2*K2);
[~,encry_order1]=sort(encry_order1);
[~,encry_order2]=sort(encry_order2);
[Logistic_matrix,~]=Logistic_2D(double(key(49:64)),wd*hd);
Logistic_matrix=Logistic_matrix*2^32;
Logistic_matrix=floor(Logistic_matrix);
index=0;
subrER=mat2cell(ER,K2*ones(1,sub_wd),K2*ones(1, sub_hd));
subrEG=mat2cell(EG,K2*ones(1,sub_wd),K2*ones(1, sub_hd));
subrEB=mat2cell(EB,K2*ones(1,sub_wd),K2*ones(1, sub_hd));
for x =1:sub_wd
    for y =1:sub_hd
        ca_matrix=ca((x-1)*K2+1:x*K2,(y-1)*K2+1:y*K2);
        [subrER{x,y},subrEG{x,y},subrEB{x,y}]=FF(subrER{x,y},subrEG{x,y},subrEB{x,y},index,K1,K2,encry_order1,encry_order2,Logistic_matrix,ca_matrix);
        index=index+(K2*K2);
    end
    DR = cell2mat(subrER);
    DG = cell2mat(subrEG);
    DB = cell2mat(subrEB);%%%逐行合并子块，最终得到单通道密文
end
DR=uint8(DR);
DG=uint8(DG);
DB=uint8(DB);
end

function [DR,DG,DB]=FF(R,G,B,index,K1,K2,encry_order1,encry_order2,Logistic_matrix,ca_matrix)
tem=index;
K=0;
P=zeros(K2,K2);
DR=zeros(K2,K2);
DG=zeros(K2,K2);
DB=zeros(K2,K2);
for K=K1:K2-K1:K2
    index=tem; %恢复index
    for i=1:K:K2-K+1
        for j=1:K:K2-K+1
            index=index+(K-2)*(K-2); %计算每个分块的index
            ca_sub=ca_matrix(i:i+K-1,j:j+K-1);
            matrix=R(i:i+K-1,j:j+K-1);
            for x=K-1:-1:2
                for y=K-1:-1:2
                    choice_1=[ca_sub(x-1,y-1),ca_sub(x,y-1),ca_sub(x-1,y),ca_sub(x-1,y+1),ca_sub(x+1,y-1),ca_sub(x+1,y),ca_sub(x,y+1),ca_sub(x+1,y+1)];
                    if sum(choice_1)>=3
                        [~,sign]=sort(choice_1,'descend');
                        neighbor=[matrix(x-1,y-1),matrix(x,y-1),matrix(x-1,y),matrix(x-1,y+1),matrix(x+1,y-1),matrix(x+1,y),matrix(x,y+1),matrix(x+1,y+1)];
                        array=[matrix(x,y),neighbor(sign(1)),neighbor(sign(2)),neighbor(sign(3))];
                        [order,num]=rank_new(array);%百十位还原
                        diff=mod(Logistic_matrix(index),num);
                        if diff==order
                            order=num;
                        elseif diff<order
                            order=order-diff;
                        else
                            order=num-diff+order;
                        end
                        array=opposite_new(order,sum(array));
                        matrix(x,y)=array(1);
                        neighbor(sign(1))=array(2);
                        neighbor(sign(2))=array(3);
                        neighbor(sign(3))=array(4);
                        [matrix(x-1,y-1),matrix(x,y-1),matrix(x-1,y),matrix(x-1,y+1),matrix(x+1,y-1),matrix(x+1,y),matrix(x,y+1),matrix(x+1,y+1)]=deal(neighbor(1),neighbor(2),neighbor(3),neighbor(4),neighbor(5),neighbor(6),neighbor(7),neighbor(8));
                        index=index-1;
                    else
                        choice_2=[ca_sub(x+1,y+1),ca_sub(x+1,y),ca_sub(x,y+1),ca_sub(x-1,y+1),ca_sub(x+1,y-1),ca_sub(x,y-1),ca_sub(x-1,y),ca_sub(x-1,y-1)];
                        [~,sign]=sort(choice_2);
                        neighbor=[matrix(x+1,y+1),matrix(x+1,y),matrix(x,y+1),matrix(x-1,y+1),matrix(x+1,y-1),matrix(x,y-1),matrix(x-1,y),matrix(x-1,y-1)];
                        array=[matrix(x,y),neighbor(sign(1)),neighbor(sign(2)),neighbor(sign(3))];
                        [order,num]=rank_new(array);%百十位还原
                        diff=mod(Logistic_matrix(index),num);
                        if diff==order
                            order=num;
                        elseif diff<order
                            order=order-diff;
                        else
                            order=num-diff+order;
                        end
                        array=opposite_new(order,sum(array));
                        matrix(x,y)=array(1);
                        neighbor(sign(1))=array(2);
                        neighbor(sign(2))=array(3);
                        neighbor(sign(3))=array(4);
                        [matrix(x+1,y+1),matrix(x+1,y),matrix(x,y+1),matrix(x-1,y+1),matrix(x+1,y-1),matrix(x,y-1),matrix(x-1,y),matrix(x-1,y-1)]=deal(neighbor(1),neighbor(2),neighbor(3),neighbor(4),neighbor(5),neighbor(6),neighbor(7),neighbor(8));
                        index=index-1;
                    end
                end
            end
            index=index+(K-2)*(K-2);
            if K==K1 %小分块
                matrix=matrix(encry_order1);
                matrix=reshape(matrix,K,K);
                P(i:i+K-1,j:j+K-1)=matrix;
            else
                matrix=matrix(encry_order2);
                matrix=reshape(matrix,K,K);
                DR(i:i+K-1,j:j+K-1)=matrix; 
            end
        end
    end
end
if Smooth_detection(DR)<Smooth_detection(P)
    K=K2;
else
    K=K1;
    DR=P;
end

if K1==K2
    start=0;
else
    start=1;
end
for t=start:2 %处理G and B
    if t==0
        P=R;
    elseif t==1
        P=G;
    else
        P=B;
    end
    index=tem;
    for i=1:K:K2-K+1
        for j=1:K:K2-K+1
            index=index+(K-2)*(K-2); %计算每个分块的index
            ca_sub=ca_matrix(i:i+K-1,j:j+K-1);
            matrix=P(i:i+K-1,j:j+K-1);
            for x=K-1:-1:2
                for y=K-1:-1:2
                    choice_1=[ca_sub(x-1,y-1),ca_sub(x,y-1),ca_sub(x-1,y),ca_sub(x-1,y+1),ca_sub(x+1,y-1),ca_sub(x+1,y),ca_sub(x,y+1),ca_sub(x+1,y+1)];
                    if sum(choice_1)>=3
                        [~,sign]=sort(choice_1,'descend');
                        neighbor=[matrix(x-1,y-1),matrix(x,y-1),matrix(x-1,y),matrix(x-1,y+1),matrix(x+1,y-1),matrix(x+1,y),matrix(x,y+1),matrix(x+1,y+1)];
                        array=[matrix(x,y),neighbor(sign(1)),neighbor(sign(2)),neighbor(sign(3))];
                        [order,num]=rank_new(array);%百十位还原
                        diff=mod(Logistic_matrix(index),num);
                        if diff==order
                            order=num;
                        elseif diff<order
                            order=order-diff;
                        else
                            order=num-diff+order;
                        end
                        array=opposite_new(order,sum(array));
                        matrix(x,y)=array(1);
                        neighbor(sign(1))=array(2);
                        neighbor(sign(2))=array(3);
                        neighbor(sign(3))=array(4);
                        [matrix(x-1,y-1),matrix(x,y-1),matrix(x-1,y),matrix(x-1,y+1),matrix(x+1,y-1),matrix(x+1,y),matrix(x,y+1),matrix(x+1,y+1)]=deal(neighbor(1),neighbor(2),neighbor(3),neighbor(4),neighbor(5),neighbor(6),neighbor(7),neighbor(8));
                        index=index-1;
                    else
                        choice_2=[ca_sub(x+1,y+1),ca_sub(x+1,y),ca_sub(x,y+1),ca_sub(x-1,y+1),ca_sub(x+1,y-1),ca_sub(x,y-1),ca_sub(x-1,y),ca_sub(x-1,y-1)];
                        [~,sign]=sort(choice_2);
                        neighbor=[matrix(x+1,y+1),matrix(x+1,y),matrix(x,y+1),matrix(x-1,y+1),matrix(x+1,y-1),matrix(x,y-1),matrix(x-1,y),matrix(x-1,y-1)];
                        array=[matrix(x,y),neighbor(sign(1)),neighbor(sign(2)),neighbor(sign(3))];
                        [order,num]=rank_new(array);%百十位还原
                        diff=mod(Logistic_matrix(index),num);
                        if diff==order
                            order=num;
                        elseif diff<order
                            order=order-diff;
                        else
                            order=num-diff+order;
                        end
                        array=opposite_new(order,sum(array));
                        matrix(x,y)=array(1);
                        neighbor(sign(1))=array(2);
                        neighbor(sign(2))=array(3);
                        neighbor(sign(3))=array(4);
                        [matrix(x+1,y+1),matrix(x+1,y),matrix(x,y+1),matrix(x-1,y+1),matrix(x+1,y-1),matrix(x,y-1),matrix(x-1,y),matrix(x-1,y-1)]=deal(neighbor(1),neighbor(2),neighbor(3),neighbor(4),neighbor(5),neighbor(6),neighbor(7),neighbor(8));
                        index=index-1;
                    end
                end
            end
            index=index+(K-2)*(K-2);
            if K==K1  %小分块
                matrix=matrix(encry_order1); 
            else
                matrix=matrix(encry_order2); 
            end
            matrix=reshape(matrix,K,K);
            P(i:i+K-1,j:j+K-1)=matrix;
        end
    end
    if t==0
        DR=P;
    elseif t==1
        DG=P;
    else
        DB=P;
    end
end
end