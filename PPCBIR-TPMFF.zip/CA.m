function ca=CA(M,N,key,n,flag) %ca矩阵大小，密钥，迭代次数
[~,Init_state]=Logistic_2D(double(key),2*(M+2)*(N+2));
Init_state_1=reshape(round(Init_state(1:(M+2)*(N+2))),M+2,N+2);
Init_state_2=reshape(round(Init_state((M+2)*(N+2)+1:2*(M+2)*(N+2))),M+2,N+2);%生成初代CA
Rule_1=[1 0 1 0 1 1 0 1 1 0 0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 1 0 1 0 0 1];
Rule_2=[0 0 1 0 1 1 0 1 0 0 0 1 1 0 0 1 1 0 0 0 1 0 1 1 1 0 1 1 0 1 1 0]; %定义规则
for t=1:n
    for i=2:M+1
        for j=2:N+1
            if t/2==0
                value=Init_state_1(i,j+1)*2^4+Init_state_1(i-1,j)*2^3+Init_state_1(i,j)*2^2+Init_state_1(i+1,j)*2+Init_state_1(i,j-1);
                Init_state_1(i,j)=bitxor(Rule_2(value+1),Init_state_2(i,j));
            else
                value=Init_state_2(i,j+1)*2^4+Init_state_2(i-1,j)*2^3+Init_state_2(i,j)*2^2+Init_state_2(i+1,j)*2+Init_state_2(i,j-1);
                Init_state_2(i,j)=bitxor(Rule_1(value+1),Init_state_1(i,j));
            end
        end
    end
end
if flag==1
    ca=Init_state_2(2:M+1,2:N+1); %去掉邻域
else
    ca=Init_state_2;
end
end




