function [x,y]=Logistic_2D(x,num)
a = java.security.MessageDigest.getInstance('MD5'); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%初始值生成部分
a.update(x);
strMD5 = sprintf('%02X',typecast(a.digest,'uint8'));%MD5算法生成128哈希值，返回16进制表示的字符串（长度为128/4=32）
a = strMD5(1:16);%取前16个字符
b = strMD5(17:32);%取后16个字符
a=hex2dec(a);%转换为十进制double类型
b=hex2dec(b);
x0 = a/b;%%%%%%得到取值为0-1之间的小数
if x0>1
    x0=1/x0;%%%%%%
end
x(1)=x0;
y(1)=x0*x0;
a=0.98;
for i=1:num
     x(i+1)=sin(pi*(4*a*x(i)*(1-x(i)))+(1-a)*sin(pi*y(i)));
     y(i+1)=sin(pi*(4*a*y(i)*(1-y(i)))+(1-a)*sin(pi*x(i).^2));  
end
end
