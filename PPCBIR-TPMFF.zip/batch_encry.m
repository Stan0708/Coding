%%
clc;clear;
warning('off');
sum=0;
for num=1396:1:1488
    str="C:\Users\14907\Desktop\image\";
    str=str+'data'+num2str(num)+'.jpg';
    P=imread(str);
    Pr = P(:,:,1);
    Pg = P(:,:,2);
    Pb = P(:,:,3);
    K=32 ;
    for i=1:1:1
        %     K = K*2;%子块大小
        T = 5;%迭代轮数
        noce=123;%特定场景
        p = 123;%密码
        c = 1;%通道
        Cr = fjiami(Pr,K,noce,p,c,T);%对r分量加密
        Cg = fjiami(Pg,K,noce,p,2,T);%对g分量加密
        Cb = fjiami(Pb,K,noce,p,3,T);%对b分量加密
        C = cat(3,Cr,Cg,Cb);
        imwrite(C,['data',num2str(num),'_32.png']);%保存加密图
        fprintf('processing %d\n',num);
    end
end


%%
warning('off');
clc;clear;
tic;
for num=1:1:1000
    str="C:\Users\14907\Desktop\corel1000\";
    str=str+num2str(num)+'.jpg';
    P=imread(str);
    I=rgb2gray(P);
    edge_1=edge(I,'Canny');
    R=P(:,:,1);
    G=P(:,:,2);
    B=P(:,:,3);
    K=16;%块大小
    key='TPE';
    ER=Encryption_edge(R,edge_1,K,key);
    EG=Encryption_edge(G,edge_1,K,key);
    EB=Encryption_edge(B,edge_1,K,key);
    C = cat(3,ER,EG,EB);
    str2="search_16\"+num2str(num)+'_16.png';
    imwrite(C,str2);
    fprintf('processing %d\n',num);
end
toc;
fprintf('加密时间%s\n',num2str(toc));


%%
clc;clear;
for num=0:1:999
    str="C:\Users\14907\Desktop\matlab_exercise\检索\";
    str=str+num2str(num)+'_8.png';%编号、块大小
    image=imread(str);
    K=4;%8、16分别代表64和32的缩略图
    M= generate_thumbnail(image,K,num);
    fprintf('processing %d\n',num);
end

%%
clc;clear;
for num=402:4:1490
    str="C:\Users\14907\Desktop\matlab_exercise\Div加密\Div64加密\";
    str=str+'data'+num2str(num)+'_64.png';
    image=imread(str);
    K=8;
    thumbnail_image=generate_thumbnail(image,K,num);
    fprintf('processing %d\n',num);
end


