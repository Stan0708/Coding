%所用自写函数
%Encryption_CA加密函数、Decryption_CA解密函数、fprng伪随机数产生函数、Logistic_2D二维混沌序列产生函数、
%CA是元胞自动机生成器、Smooth_detection
clc;clear;close all;
warning('off');
tic; 
K1=32;
K2=32;%块大小
key='difference attackdifference attackdifference attackdifference attackdifference attackdifference attack';
str="C:\Users\14907\Desktop\algorithm 1\code\matlab_exercise\test_image\";  %原图像地址
str1="C:\Users\14907\Desktop\algorithm 1\code\matlab_exercise\detection result\"; %突出检测文件地址
% str2="C:\Users\14907\Desktop\matlab_exercise\test_result\";  %密文和解密图像地址
% str="C:\Users\14907\Desktop\matlab_exercise\diff\";  %原图像地址
str2="C:\Users\14907\Desktop\algorithm 1\code\matlab_exercise\test_result\diff attack\Baboon\";  %密文和解密图像地址
name="Baboon"; %图片名称
str=str+name+".png";
str1=str1+name+".png";
P=imread(str);
salient_object=imread(str1);


salient_object=im2bw(salient_object,0.1);  %二值化处理
[wd,hd] = size(salient_object);
sub_wd = wd / K2;
sub_hd = hd / K2;
sign_matrix=zeros(sub_wd,sub_hd);
for i=1:K2:wd-K2+1
    for j=1:K2:hd-K2+1
        sign_matrix(((i-1)/K2)+1,((j-1)/K2)+1)=sum(sum(salient_object(i:i+K2-1,j:j+K2-1)));
    end
end
%%差分攻击测试
% for i=1:K1:wd-K1+1
%     for j=1:K1:hd-K1+1
%         for pp=1:3
%             matrix=P(i:i+K1-1,j:j+K1-1,pp);
%             randx=randi([1, K1]);
%             randy=randi([1, K1]);
%             if (matrix(randx,randy)>128)
%                 matrix(randx,randy)=matrix(randx,randy)-5;
%             else
%                 matrix(randx,randy)=matrix(randx,randy)+5;
%             end
%             P(i:i+K1-1,j:j+K1-1,pp)=matrix;
%         end
%     end
% end
ER=P(:,:,1);
EG=P(:,:,2);
EB=P(:,:,3);
for t=1:1
    key=key+num2str(mod(t,10));
    ca=CA(wd,hd,double(key(1:32)),mod(10+t,50),1);
    fprintf('encryption start---%d\n',t);
    ER=Encryption_CA(ER,sign_matrix,ca,K1,K2,key);
%     fprintf('encryption success -------R\n');
    EG=Encryption_CA(EG,sign_matrix,ca,K1,K2,key);
%     fprintf('encryption success -------G\n');
    EB=Encryption_CA(EB,sign_matrix,ca,K1,K2,key);
%     fprintf('encryption success -------B\n');
end
% ER=P(:,:,1);
% EG=P(:,:,2);
% EB=P(:,:,3);
C = cat(3,ER,EG,EB);
imshow(C);
imwrite(C,[str2+name+'_'+num2str(K2)+'ori200.png']);
% toc
% disp(['加密运行时间: ',num2str(toc)]);
% tic;
% DR=ER;DG=EG;DB=EB;
% for t=1:-1:1
%     key='KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK';
%     ca=CA(wd,hd,double(key(1:32)),mod(10+t,50),1);
%     fprintf('encryption start---%d\n',t);
%     [DR,DG,DB]=Decryption_CA(DR,DG,DB,ca,K1,K2,key);
% end
% D = cat(3,DR,DG,DB);
% imwrite(D,[str2+name+'_JIE'+num2str(K2)+'.png']);
% toc
% disp(['解密运行时间: ',num2str(toc)]);
% subplot(1,2,1);
% imshow(C);
% title('加密')
% subplot(1,2,2);
% imshow(D);
% title('解密')
