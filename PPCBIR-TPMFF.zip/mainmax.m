function [H] = mainmax(f,patchSize)
% 读入RGB图像
%f = imread('SCI01.bmp');
im = imresize(f,[512,512]);
ycbcrImage = rgb2ycbcr(im);
%fim = rgb2gray(im);
fim = im2double(ycbcrImage);
[entropy,lsd,T,T1] = findVacancy(im);%该函数用于发现空白块
%patches = partition_my(fim,patchSize);
patches = getImagePatches_3(fim, patchSize);
yImage = patches(:,:,1);
[a,b] = size(yImage);
[a,b,c] = size(patches);
intensity = zeros(a, b);
for x = 1:a
    for y = 1:b
        cur_block = yImage{x,y};%读块
        avgIntensity = mean(cur_block(:));
        intensity(x, y) = avgIntensity;
    end
end
averge = mean(intensity(:));
bt = cell(1,1);
bp = cell(1,1);
k1 = 1;
k2 = 1;
 folderPath1 = 'C:\Users\13268\Desktop\FK\image_blocks';
 folderPath2 = 'C:\Users\13268\Desktop\FK\text_blocks';
for m=1:a
    for n=1:b
        block = patches{m,n};
        if entropy(m,n)>T || lsd(m,n)>T1 %%排除空白块
            if intensity(m,n) > averge
                bt{k1,1} = block; 
                fileName = sprintf('block_%d_%d.png', m, n);
                filePath = fullfile(folderPath2, fileName);
                imwrite(block, filePath);
                k1 = k1 + 1;
            else
                bp{k2,1} = block;
                fileName = sprintf('block_%d_%d.png', m, n);
                filePath = fullfile(folderPath1, fileName);
                imwrite(block, filePath);
                k2 = k2 + 1;
            end
        end
    end
end

end