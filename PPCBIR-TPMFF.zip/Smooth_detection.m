function var=Smooth_detection(P)
double(P);
[wd,hd]=size(P);
var=0;
for x=1:2:(wd-1)
    for y=1:2:(hd-1)
        matrix_2x2=P(x:(x+1),y:(y+1));
        var=var+sum(sum((abs(matrix_2x2-mean(mean(matrix_2x2)))).^2))/4;
    end
end
end