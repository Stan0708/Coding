function ca=CA2(M,N,key,n,flag) %ca矩阵大小，密钥，迭代次数
[~,Init_state]=Logistic_2D(double(key),4356);
Init_state=round(Init_state(1:4356));
Rule_1=[0,1,0,1,0,1,1,0];
for t=1:n
    for i=2:4355
        value=Init_state(1,i-1)*2^2+Init_state(1,i)*2+Init_state(1,i+1);
        Init_state(1,i)=Rule_1(value+1);
    end
end
Init_state=reshape(Init_state,M+2,N+2);
ca=Init_state(2:M+1,2:N+1);
end
