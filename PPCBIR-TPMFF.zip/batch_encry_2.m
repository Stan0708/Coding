%%%  批量加密 557
clc;clear;
warning('off');

key='KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK';
K1=8;
K2=32;
tic;
for t=1:500
    str="C:\Users\14907\Desktop\dataset\helen_dataset\reshape\image_process\"; %原图像地址
    str1="C:\Users\14907\Desktop\dataset\helen_dataset\encry\8_32\"; %密文图像地址
    str2="C:\Users\14907\Desktop\dataset\helen_dataset\detection result\"; %突出检测文件地址
    str=str+num2str(t)+".png";
    str1=str1+num2str(t)+".png";
    str2=str2+num2str(t)+".png";
    P=imread(str);
    salient_object=imread(str2);
    salient_object=im2bw(salient_object,0.1);  %二值化处理
    [wd,hd] = size(salient_object);
    sub_wd = wd / K2;
    sub_hd = hd / K2;
    sign_matrix=zeros(sub_wd,sub_hd);
    for i=1:K2:wd-K2+1
        for j=1:K2:hd-K2+1
            sign_matrix(((i-1)/K2)+1,((j-1)/K2)+1)=sum(sum(salient_object(i:i+K2-1,j:j+K2-1)));
        end
    end
    ER=P(:,:,1);
    EG=P(:,:,2);
    EB=P(:,:,3);
    for itera=1:1
        ca=CA(wd,hd,double(key),10,1);
        ER=Encryption_CA(ER,sign_matrix,ca,K1,K2,key);
        EG=Encryption_CA(EG,sign_matrix,ca,K1,K2,key);
        EB=Encryption_CA(EB,sign_matrix,ca,K1,K2,key);
    end
    C = cat(3,ER,EG,EB);
    imwrite(C,str1);
    fprintf('process success %d \n',t);
end
toc;
disp(['时间: ',num2str(toc)]);
