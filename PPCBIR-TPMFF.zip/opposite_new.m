function array=opposite_new(order,sum_4)
array=[0,0,0,0];
num=0;
if sum_4>510
    start=sum_4-510;
else
    start=0;
end
for left=start:1:min(510,sum_4)
    right=sum_4-left;
    if left<=255
        left_num=left+1;
    else
        left_num=511-left;
    end
    if right<=255
        right_num=right+1;
    else
        right_num=511-right;
    end
    if order<=num+left_num*right_num
        if left>255
            start=left-255;
        else
            start=0;
        end
        for left_L=start:1:min(255,left)
            if order<=num+(left_L-start+1)*right_num
                array(1)=left_L;
                array(2)=left-left_L;
                array(3)=order-num-(left_L-start)*right_num;
                if right>255
                    start=right-255;
                else
                    start=0;
                end
                for right_L=start:1:min(255,right)
                    if right_L-start+1==array(3)
                        array(3)=right_L;
                        array(4)=right-right_L;
                        break;
                    end
                end
                break;
            end
        end
        break;
    else
        num=num+right_num*left_num;
    end
end