%%
clc;clear;
image=imread("C:\Users\14907\Desktop\matlab_exercise\test_image\lena.png");
image=generate_thumbnail(image,64,64,"aieplane1_thumb");

%%
clc;clear;
I1=imread("C:\Users\14907\Desktop\background\DUTS\5.png");
I2=imread("C:\Users\14907\Desktop\background\result\5.png");
I2=imread("C:\Users\14907\Desktop\background\result32\5.png");
psnr=fmssim(I1,I2);

%%
image=imread("C:\Users\14907\Desktop\matlab_exercise\test_result\lena_32.png");
image=uint8(image);
imhist(image(:,:,1));

%%
